# UNIVERSIDAD DE BUENOS AIRES FACULTAD DE  INGENIERÍA
# Departamento de Computación

# 75.12 | 95.04 - Análisis Numérico I – Curso 7

# 95.13 – Métodos Matemáticos y Numéricos – Curso 7

# 95.04 – Modelación Numérica – Curso 2

# 2º Cuatrimestre de 2015

# TRABAJO PRÁCTICO 1
# Ajuste e Interpolación Sistemas de Ecuaciones Lineales

Profesor Titular:  Ing. Rodolfo Schwarz - Jefe de TP: Ing. Germán E. Sosa

Docentes:
Ing. Florencia Lanteri, Ing. Micaela Suriano, Mara Eidelsztein

Integrantes:

Botalla, Tomás Enrique;
Ledesma, Juan Sebastián;
Peragallo Sommer, Claudia G.;
Vido, Hernán Andrés;
